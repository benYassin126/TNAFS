<!DOCTYPE html>
<html>
<head>
    <title>طباعة</title>
        <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <link rel="stylesheet"href="/css/app.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/design/AdminLTE/dist/css/adminlte.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/design/AdminLTE/dist/css/bootstrap-rtl.min.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/design/AdminLTE/dist/css/custom-style.css">
</head>
<style>
@media  print {
   .noprint {
      visibility: hidden;
   }
}
</style>
<body>
    <!-- Strat MSG -->
<div class="row">
    <div class="card mt-4 text-center" style="width: 100%">
        <div class="card-header">

         <form action="<?php echo e(route('print.sort')); ?>" method="post" class="noprint">
            <?php echo csrf_field(); ?>
            <!-- select -->
            <div class="form-group mb-4">
                <select class="form-control" required name="StudentGroup" >
                    <option value="0">عرض جميع المجموعات</option>
                    <?php $__currentLoopData = $allGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option  value="<?php echo e($group->id); ?>"  <?php if(isset($GroupTitle) && $GroupTitle->GroupName == $group->GroupName): ?> selected <?php endif; ?> ><?php echo e($group->GroupName); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit" class="btn btn-info mt-2">تخصيص المجموعة  <i class="fas fa-search"></i></button>
            </div>
        </form>





        <a  onclick="window.print()" class="btn btn-warning btn-block noprint"><i class="fas fa-print"></i> طباعة النتائج</a>
    </div>
    <!-- /.card-header -->
    <div class="card-body table-responsive-sm">























