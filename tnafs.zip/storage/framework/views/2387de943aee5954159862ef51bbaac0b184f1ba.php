<?php $__env->startSection('title','المجموعات'); ?>
<?php $__env->startSection('content'); ?>


<!-- Main content -->
<div class="content">
  <div class="container-fluid">
    <!-- Strat MSG -->
<?php if(session()->has('message')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert" id="display-success">
       <strong><?php echo e(session()->get('message')); ?></strong>
       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php endif; ?>

<?php if(session()->has('ErorrMsg')): ?>
    <div class="alert alert-danger fade show" role="alert" id="display-success">
       <strong><?php echo e(session()->get('ErorrMsg')); ?></strong>
       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php endif; ?>

<?php if($errors->any()): ?>
<div class="alert-dismissible  alert alert-danger" id="display-success">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<!-- END MSG -->



<div class="row">
    <div class="card mt-4 text-center">
        <div class="card-header">
        <a href="<?php echo e(route('group.create')); ?>" class="btn btn-success btn-block mt-4"><i class="fas fa-user"></i> اضافة مجموعة</a>
        <a href="<?php echo e(route('print')); ?>" class="btn btn-warning btn-block"><i class="fas fa-print"></i> طباعة النتائج</a>
    </div>
    <!-- /.card-header -->
    <div class="card-body table-responsive-sm">
      <table class="table  table-bordered table-striped">
        <thead>
            <tr>
              <th>#</th>
              <th>اسم  المجموعة</th>
              <th> عدد الطلاب</th>
              <th>نقاط المجموعة</th>
              <th>التحكم</th>
          </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $allGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kay=>$group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($kay+1); ?></td>
            <td><?php echo e($group->GroupName); ?></td>
            <td><?php echo e($Students->where('StudentGroup',$group->id)->count()); ?></td>
            <td><?php echo e($group->GroupPoints); ?></td>
            <td>


                <buttn data-toggle="modal" data-target="#<?php echo e($group->id); ?>" class="btn btn-primary "><i class="fas fa-plus-circle"></i></buttn>


                <!-- Modal -->
                <div class="modal fade" id="<?php echo e($group->id); ?>"  role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalCenterTitle">اضافة او خصم نقاط</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                      </button>
                  </div>
                  <div class="modal-body">
                    <form action="<?php echo e(route('group.points')); ?>" method="Post">
                        <?php echo csrf_field(); ?>
                        <input type="number" step="0.01"  name="points" placeholder="0" autofocus required> <span class="pl-2">نقطة</span>
                        <input type="text" name="id" value="<?php echo e($group->id); ?>" style="display: none;">
                        <button type="submit" name="add" class="btn btn-success">اضافة</button>
                        <button type="submit" name="dis" class="btn btn-danger">خصم</button>
                    </form>
                </div>

                <button type="button" class="btn btn-danger" data-dismiss="modal">اغلاق</button>
            </div>
        </div>
    </div>









    <a href="<?php echo e(route('group.edit',$group->id)); ?>" class="btn btn-info "><i class="fas fa-edit"></i></a>


     <form method="post" action="<?php echo e(route('group.destroy',$group->id)); ?>" style="display: inline-block;">
      <?php echo csrf_field(); ?>
         <?php echo method_field('DELETE'); ?>
        <button onclick="return confirm('<?php echo e(__('هل انت متاكد ؟')); ?>')"  class="btn btn-danger "><i class="fas fa-trash-alt"></i></buttn>
      </form>
  </td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

<div class="alert alert-danger  fade show" role="alert">
   <h4>لم تقم باضافة اي مجموعة بعد</h4>
   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
</button>
</div>
<a href="<?php echo e(route('group.create')); ?>" class="btn btn-info mb-4"><i class="fas fa-plus"></i> اضافة مجموعة </a>

<?php endif; ?>
</tbody>
<tfoot>

</tfoot>
</table>
</div>
<!-- /.card-body -->
</div>
<!-- /.card -->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.adminLTE', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>