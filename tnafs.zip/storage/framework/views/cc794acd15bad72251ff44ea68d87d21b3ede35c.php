

<?php echo csrf_field(); ?>
<div class="card-body">
  <div class="form-group">
    <label class="control-label">اسم الطالب</label>

    <div>
      <input type="text" class="form-control"  placeholder="اسم الطالب"  autofocus name="StudentName" <?php if(isset($thisStudent)): ?> value="<?php echo e($thisStudent->StudentName); ?>" <?php endif; ?> required >
  </div>
</div>
<!-- select -->
<div class="form-group">
    <label>مجموعة الطالب  [ <a href="<?php echo e(route('group.create')); ?>" class="btn btn-link">اضافة  مجموعة</a> ]</label>
   <?php if($allGroups == '[]'): ?>
    <div class="alert alert-danger fade show" role="alert">
     <p>لايمكنك اضافة اي طالب  حتى تقوم بانشاء مجموعة واحدة على الاقل</p>
     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    </div>
       <a href="<?php echo e(route('group.create')); ?>" class="btn btn-info mb-4"><i class="fas fa-plus"></i> اضافة مجموعة </a>
   <?php endif; ?>
    <select class="form-control" required name="StudentGroup">
       <?php $__currentLoopData = $allGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <option value="<?php echo e($group->id); ?>"  <?php if(isset($thisStudent) && $thisStudent->StudentGroup == $group->id ): ?> selected <?php endif; ?>><?php echo e($group->GroupName); ?></option>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </select>
</div>



</div>


