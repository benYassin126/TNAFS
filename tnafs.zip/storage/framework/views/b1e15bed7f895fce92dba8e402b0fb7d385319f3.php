<!DOCTYPE html>
<html>
<head>
    <title>تنافس</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <link rel="stylesheet"href="/css/app.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/design/AdminLTE/dist/css/adminlte.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/design/AdminLTE/dist/css/bootstrap-rtl.min.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/design/AdminLTE/dist/css/custom-style.css">
</head>
<body class="StudentBody">
    <div class="container">
        <h3 class="text-center mt-4"></h3>
        <div class="row">
            <div class="col-sm-12">
               <div class="card mt-4 ">

                  <div class="card-footer">
                    <h4 class="text-center"> الصدارة لــ  <span class="win"> <?php $__currentLoopData = $topNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($name); ?> || <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  <i class="fas fa-crown"></i></span></h4>
                </div>
                <div class="card-body">
                    <table class="table table-bordered studentTable">
                      <thead>
                        <tr>
                            <th scope="col">الترتيب</th>
                          <th scope="col">الأسم</th>
                          <th scope="col">المجموعة</th>
                          <th scope="col">النقاط</th>
                      </tr>
                      <?php $__empty_1 = true; $__currentLoopData = $allStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kay=>$student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                      <?php if(in_array($student->StudentName , $topNames)): ?>
                      <tr class="topNames">
                        <td><?php echo e($orderArray[$kay]); ?> </td>
                        <td><i class="fas fa-crown"></i> <?php echo e($student->StudentName); ?></td>
                        <td><?php echo e($student->group->GroupName); ?></td>
                        <td><?php echo e($student->StudentPoints); ?></td>
                    </tr>
                    <?php else: ?>
                    <tr>
                        <td><?php echo e($orderArray[$kay]); ?></td>
                        <td><?php echo e($student->StudentName); ?></td>
                        <td><?php echo e($student->group->GroupName); ?></td>
                        <td><?php echo e($student->StudentPoints); ?></td>
                    </tr>
                    <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>لا يوجد طلاب</p>
                    <?php endif; ?>
                </thead>
                <tbody>

                </tbody>
            </table>

        </div>
        <div class="card-footer">
            <button  onClick="window.location.reload();" class="btn btn-primary btn-block">تحديث النتائج   <i class="fas fa-sync-alt"></i></button>
        </div>
    </div>
</div>
</div>


<hr>




<h3 class="text-center mt-4">المجموعات</h3>
<div class="row">
    <div class="col-sm-12">
       <div class="card mt-4 ">
          <div class="card-footer">
            <h4 class="text-center"> الصدارة لــ  <span class="win"> <?php $__currentLoopData = $topNamesGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($name); ?> || <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  <i class="fas fa-crown"></i></span></h4>
        </div>
        <div class="card-body">
            <table class="table table-bordered studentTable">
              <thead>
                <tr>
                  <th scope="col">الترتيب</th>
                  <th scope="col">المجموعة</th>
                  <th scope="col">النقاط</th>
              </tr>
              <?php $__empty_1 = true; $__currentLoopData = $allGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kay=>$group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

              <?php if(in_array($group->GroupName , $topNamesGroup)): ?>
              <tr class="topNames">
                <td><?php echo e($orderArrayGroup[$kay]); ?> </td>
                <td><i class="fas fa-crown"></i> <?php echo e($group->GroupName); ?></td>
                <td><?php echo e($group->GroupPoints); ?></td>
            </tr>
            <?php else: ?>
            <tr>
                <td><?php echo e($orderArrayGroup[$kay]); ?></td>
                <td><?php echo e($group->GroupName); ?></td>
                <td><?php echo e($group->GroupPoints); ?></td>
            </tr>
            <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>لا يوجد  مجموعات</p>
            <?php endif; ?>
        </thead>
        <tbody>

        </tbody>
    </table>

</div>
<div class="card-footer">
    <button  onClick="window.location.reload();" class="btn btn-primary btn-block">تحديث النتائج   <i class="fas fa-sync-alt"></i></button>
</div>
</div>
</div>
</div>





</div>


</body>


<script src="<?php echo e(url('/')); ?>/design/AdminLTE/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(url('/')); ?>/design/AdminLTE/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(url('/')); ?>/design/AdminLTE/dist/js/adminlte.js"></script>

</html>
