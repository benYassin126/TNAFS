<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLTE', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>