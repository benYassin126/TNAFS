<?php $__env->startSection('title','الطلاب'); ?>
<?php $__env->startSection('content'); ?>


<!-- Main content -->
<div class="content">
  <div class="container-fluid">
    <!-- Strat MSG -->
    <!-- Strat MSG -->
    <?php if(session()->has('message')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert" id="display-success">
     <strong><?php echo e(session()->get('message')); ?></strong>
     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert-dismissible  alert alert-danger" id="display-success">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<!-- Strat MSG -->
<div class="row">
    <div class="card mt-4 text-center">
        <div class="card-header">

         <form action="<?php echo e(route('student.sort')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <!-- select -->
            <div class="form-group mb-4">
                <select class="form-control" required name="StudentGroup" >
                    <option value="0">عرض جميع المجموعات</option>
                    <?php $__currentLoopData = $allGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option  value="<?php echo e($group->id); ?>"  <?php if(isset($GroupTitle) && $GroupTitle->GroupName == $group->GroupName): ?> selected <?php endif; ?> ><?php echo e($group->GroupName); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit" class="btn btn-info mt-2">تخصيص المجموعة  <i class="fas fa-search"></i></button>
            </div>
        </form>


        <form action="<?php echo e(route('student.search')); ?>" method="post" onsubmit="return false">
            <?php echo csrf_field(); ?>
            <input class="form-control form-control"  id="search" name="search" type="search" placeholder="بحث عن طالب" aria-label="Search" >
        </form>



        <a href="<?php echo e(route('student.create')); ?>" class="btn btn-success btn-block mt-4"><i class="fas fa-user"></i> اضافة طالب  </a>
        <a href="<?php echo e(route('print')); ?>" class="btn btn-warning btn-block"><i class="fas fa-print"></i> طباعة النتائج</a>
    </div>
    <!-- /.card-header -->
    <div class="card-body table-responsive-sm">
      <table class="table  table-bordered table-striped">
        <thead>
            <tr>
              <th>#</th>
              <th>اسم الطالب</th>
              <th>مجموعة الطالب</th>
              <th>نقاط الطالب</th>
              <th>التحكم</th>
          </tr>
      </thead>
      <tbody>
        <?php if(isset($GroupTitle)): ?> <h4 class="mb-4"> [ <?php echo e($GroupTitle->GroupName); ?> ] جميع الطلاب  </h4> <?php endif; ?>
        <?php $__empty_1 = true; $__currentLoopData = $allStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kay=>$student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>


        <tr>
            <td><?php echo e($kay+1); ?></td>
            <td><?php echo e($student->StudentName); ?></td>
            <td><?php echo e($student->group->GroupName); ?></td>
            <td><?php echo e($student->StudentPoints); ?></td>
            <td>


                <buttn data-toggle="modal" data-target="#<?php echo e($student->id); ?>" class="btn btn-primary "><i class="fas fa-plus-circle"></i></buttn>


                <!-- Modal -->
                <div class="modal fade" id="<?php echo e($student->id); ?>"  role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalCenterTitle">اضافة او خصم نقاط</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                      </button>
                  </div>
                  <div class="modal-body">
                    <form action="<?php echo e(route('student.points')); ?>" method="Post">
                        <?php echo csrf_field(); ?>
                        <input type="number" step="0.01"  name="points" placeholder="0" autofocus required> <span class="pl-2">نقطة</span>
                        <input type="text" name="id" value="<?php echo e($student->id); ?>" style="display: none;">
                        <button type="submit" name="add" class="btn btn-success">اضافة</button>
                        <button type="submit" name="dis" class="btn btn-danger">خصم</button>
                    </form>
                </div>

                <button type="button" class="btn btn-danger" data-dismiss="modal">اغلاق</button>
            </div>
        </div>
    </div>









    <a href="<?php echo e(route('student.edit',$student->id)); ?>" class="btn btn-info "><i class="fas fa-edit"></i></a>


    <form method="post" action="<?php echo e(route('student.destroy',$student->id)); ?>" style="display: inline-block;">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
      <button onclick="return confirm('<?php echo e(__('هل انت متاكد ؟')); ?>')" class="btn btn-danger "><i class="fas fa-trash-alt"></i></buttn>
      </form>
  </td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

    <div class="alert alert-danger  fade show" role="alert">
     <h4>لم تقم باضافة اي طالب بعد</h4>
     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    </div>
       <a href="<?php echo e(route('student.create')); ?>" class="btn btn-info mb-4"><i class="fas fa-plus"></i> اضافة طالب </a>

<?php endif; ?>
</tbody>
<tfoot>

</tfoot>
</table>
</div>
<!-- /.card-body -->
</div>
<!-- /.card -->

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.adminLTE', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>