<?php $__env->startSection('title','تعديل طالب'); ?>

<?php $__env->startSection('content'); ?>

<!-- Main content -->
<div class="content">
  <div class="container-fluid">

<!-- Strat MSG -->
   <?php if(session()->has('message')): ?>
   <div class="alert alert-success alert-dismissible fade show" role="alert">
       <strong><?php echo e(session()->get('message')); ?></strong>
       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<?php endif; ?>
    <!-- END MSG -->
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<!-- Strat MSG -->

    <div class="card card-info mb-4">
     <div class="card-header">
        <h3 class="card-title" style="display: inline-block;">تعديل بينات  [ <?php echo e($thisStudent->StudentName); ?> ]</h3>
                 <form method="Post" action="<?php echo e(route('student.destroy',$thisStudent->id)); ?>" style="float: left;">
          <?php echo csrf_field(); ?>
          <?php echo method_field('DELETE'); ?>
          <button onclick="return confirm('<?php echo e(__('هل انت متاكد ؟')); ?>')"  href="<?php echo e(route('student.destroy',$thisStudent->id)); ?>" class="btn btn-danger "><i class="fas fa-trash-alt"></i>  حذف الطالب </buttn>
          </form>
    </div>
    <!-- /.card-header -->
    <!-- form start -->
    <form action="<?php echo e(route('student.update',$thisStudent)); ?>" method="post">
        <?php echo method_field('PATCH'); ?>

        <?php echo $__env->make('layouts.student._part._studentForm', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- START PLAY -->
        <hr>
<div class="text-center mb-4 pb-4">
    <h4 class="text-center mb-4">اضف نقاط لـ  <?php echo e($thisStudent->StudentName); ?></h4>
                <input type="number" step="0.01"  name="points" placeholder="0" autofocus> <span class="pl-2">نقطة</span>
                <input type="text" name="id" value="<?php echo e($thisStudent->id); ?>" style="display: none;">
                <button type="submit" name="add" class="btn btn-success"><i class="fas fa-plus fa-sm"></i> اضافة</button>
                <button type="submit" name="dis" class="btn btn-danger"><i class="fas fa-minus fa-sm"></i>  خصم</button>

</div>
<!-- START PLAY -->



<div class="card-footer">

    <button type="submit" name="update" class="btn btn-success btn-block"> <i class="fas fa-edit fa-sm"></i> حفظ التعديلات  </button>

</div>


</form>

<!-- /.card-body -->

</div>

<!-- /.card -->




<!-- Horizontal Form -->




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLTE', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>