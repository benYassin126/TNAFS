<?php $__env->startSection('title','الطلاب'); ?>
<?php $__env->startSection('content'); ?>


<!-- Main content -->
<div class="content">
  <div class="container-fluid">
    <!-- Strat MSG -->
    <?php if(session()->has('message')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert" id="display-success">
     <strong><?php echo e(session()->get('message')); ?></strong>
     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
  <?php endif; ?>

  <?php if($errors->any()): ?>
  <div class="alert-dismissible  alert alert-danger" id="display-success">
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
  <?php endif; ?>
  <!-- End MSG -->


  <!-- Start Content -->

  <!-- Small boxes (Stat box) -->
  <div class="row">
    <div class="col-lg-6">
      <!-- small box -->
      <div class="small-box bg-info">
        <div class="inner">
          <h3><?php echo e($countStudent); ?></h3>

          <p>الطلاب</p>
        </div>
        <div class="icon">
          <i class="ionicons ion-android-person"></i>
        </div>
        <a href="<?php echo e(route('student.index')); ?>" class="small-box-footer">الذهاب للتحكم بالطلاب <i class="fa fa-arrow-circle-left"></i></a>
      </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-6 ">
      <!-- small box -->
      <div class="small-box bg-success">
        <div class="inner">
          <h3><?php echo e($countGroup); ?></h3>

          <p>المجموعات</p>
        </div>
        <div class="icon">
          <i class="ionicons ion-person-stalker"></i>
        </div>
        <a href="<?php echo e(route('group.index')); ?>" class="small-box-footer"> الذهاب للتحكم بالمجموعات  <i class="fa fa-arrow-circle-left"></i></a>
      </div>
    </div>
    <!-- ./col -->
  </div>
  <!-- /.row -->

  <div class="text-center mb-4">

      <h4 class="mt-4 mb-2">رابط عرض النتائج للطلاب</h4>
      <input type="text" id="PasteLink" value="<?php echo e(url('/')); ?>/<?php echo e($StudentLink); ?>" class="form-control PasteLink">
      <button onclick="PasteLinkFunction()" class="btn btn-primary mt-2"><i class="fas fa-copy "></i> نسخ الرابط</button>
       <a href="<?php echo e(url('/')); ?>/<?php echo e($StudentLink); ?>" target="_blank" class="btn btn-info mt-2">الذهاب لصفحة الطلاب   <i class="fas fa-arrow-circle-left"></i></a>

  </div>
  <!-- Main row -->



  <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.adminLTE', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>