

<?php echo csrf_field(); ?>
<div class="card-body">
  <div class="form-group">
    <label class="control-label">اسم المجموعة</label>

    <div>
      <input type="text" class="form-control"  placeholder="اسم  المجموعة"  autofocus name="GroupName" <?php if(isset($thisGroup)): ?> value="<?php echo e($thisGroup->GroupName); ?>" <?php endif; ?> required >
  </div>
</div>



</div>


