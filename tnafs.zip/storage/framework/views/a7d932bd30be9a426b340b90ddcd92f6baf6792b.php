<!DOCTYPE html>
<html>
<head>
    <title>طباعة</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <link rel="stylesheet"href="/css/app.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/design/AdminLTE/dist/css/adminlte.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/design/AdminLTE/dist/css/bootstrap-rtl.min.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/design/AdminLTE/dist/css/custom-style.css">
    <style>
        @media  print {
         .noprint {
          visibility: hidden;
      }
  }

</style>
</head>
<div class="text-center">
  <button  onclick="window.print()" class="mt-4 mb-4 btn btn-warning  noprint"><i class="fas fa-print"></i> اطــــــبــــــع</button>
  <button   onclick="window.history.back()" class="mt-4 mb-4 btn btn-primary  noprint"><i class="fas fa-undo-alt"></i> عودة</button>
</div>



<table class="table  table-bordered table-striped">
    <thead>
        <tr>
          <th>#</th>
          <th>اسم الطالب</th>
          <th>مجموعة الطالب</th>
          <th>نقاط الطالب</th>
      </tr>
  </thead>
  <tbody>
     <h4 class="mb-4 text-center"> [ <?php echo e($GroupTitle); ?> ]</h4>
     <?php $__empty_1 = true; $__currentLoopData = $allStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kay=>$student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
     <tr>
        <td><?php echo e($kay+1); ?></td>
        <td><?php echo e($student->StudentName); ?></td>
        <td><?php echo e($student->group->GroupName); ?></td>
        <td><?php echo e($student->StudentPoints); ?></td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    ا
    <?php endif; ?>
</tbody>
<tfoot>

</tfoot>
</table>

